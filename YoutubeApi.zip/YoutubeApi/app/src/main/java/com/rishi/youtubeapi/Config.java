package com.rishi.youtubeapi;

public class Config {
    public static final String YOUTUBE_API_KEY = "AIzaSyAwHFBS3Y5FLVp14My_VMZdMjxYMV059f0";
}
